#ifndef STRING_EQUAL
#define STRING_EQUAL
int stringequal (char *,char *);        //la función compara si dos strings son iguales, devuelve 1 si lo son y cero si no
int wordlength (char *);                //la función calcula la cantidad de caracteres en un string
#define BOOLEAN int
#define OK 1
#define NOT_EQUAL 0
#endif
