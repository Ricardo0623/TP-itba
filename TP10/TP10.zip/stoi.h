#ifndef STI_H
#define STI_H
int stoi(char *num);  //la función transforma un string en un int
#endif
