#ifndef DICE_H
#define DICE_H
void dice(int cantidad, int tiradas, int caras, char *nombre_archivo);	//la función simula una cantidad de tiradas de dados e imprime el resultado en el archivo indicado o en pantalla
#endif
