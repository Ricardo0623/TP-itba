#ifndef VERFY_H
#define VERFY_H
int verify(char *num);		// la función verifica que un string esté compuesto sólo por caracteres que representen números. Devuelve 1 si hay sólo números y 0 de lo contrario
#endif
