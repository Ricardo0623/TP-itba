#ifndef VALIDATIONH
#define VALIDATIONH
#define CANTDEARG 8
#define CANTDEARG2 7
int validation (int, char *[]); // recibe cantidad de argumentos y arreglo de punteros
#endif
